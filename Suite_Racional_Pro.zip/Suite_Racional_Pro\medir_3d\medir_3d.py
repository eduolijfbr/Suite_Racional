import os
from qgis.PyQt.QtCore import Qt, QVariant
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QMessageBox
from qgis.core import QgsProject, QgsMapLayerType, QgsSettings, QgsVectorLayer, QgsField, QgsMessageLog, Qgis
from .medir_3d_dockwidget import Medir3DDockWidget
from .maptool_3d import MapTool3D

class Medir3DPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.dockwidget = None
        self.action = None
        self.map_tool = None
        self.active_projeto_id = None

    def initGui(self):
        # Configurar menu e barra de ferramentas
        from qgis.PyQt.QtWidgets import QToolBar
        icon_path = os.path.join(self.plugin_dir, 'icon.svg')
        self.action = QAction(QIcon(icon_path), "Medir 3D", self.iface.mainWindow())
        self.action.setObjectName("Medir3DAction")
        self.action.setWhatsThis("Medir distâncias e perfis 3D")
        self.action.setStatusTip("Abrir painel Medir 3D")
        self.action.triggered.connect(self.run)

        self.toolbar_name = 'SuiteRacionalPro'
        self.toolbar = self.iface.mainWindow().findChild(QToolBar, self.toolbar_name)
        if not self.toolbar:
            self.toolbar = self.iface.addToolBar('Suite Racional Pro')
            self.toolbar.setObjectName(self.toolbar_name)
            
        self.toolbar.addAction(self.action)
        self.iface.addPluginToMenu("&Suite Racional Pro", self.action)

    def unload(self):
        self.limpar_dados(permanente=True)
        if self.dockwidget:
            self.iface.removeDockWidget(self.dockwidget)
        self.iface.removePluginMenu("&Suite Racional Pro", self.action)
        if hasattr(self, 'toolbar') and self.toolbar:
            self.toolbar.removeAction(self.action)

    def run(self):
        if not self.dockwidget:
            self.dockwidget = Medir3DDockWidget()
            self.iface.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.dockwidget)
            
            # Conectar sinais
            self.dockwidget.btn_medir_distancia.clicked.connect(self.ativar_medicao)
            self.dockwidget.btn_limpar.clicked.connect(self.limpar_dados)
            self.dockwidget.btn_salvar.clicked.connect(self.salvar_no_banco)
            self.dockwidget.btn_atualizar_pvs.clicked.connect(self.atualizar_pvs)
            self.dockwidget.btn_perfil.clicked.connect(self.ver_perfil)
            self.dockwidget.visibilityChanged.connect(self.dock_visibility_changed)
            self.dockwidget.combo_layer.currentIndexChanged.connect(self.guardar_selecao_camada)
            self.dockwidget.combo_bacias.currentIndexChanged.connect(self.guardar_selecao_camada)
            self.dockwidget.combo_vias.currentIndexChanged.connect(self.atualizar_campos_vias)
            self.dockwidget.btn_carregar_historico.clicked.connect(self.carregar_historico)
            self.dockwidget.btn_excluir_historico.clicked.connect(self.excluir_historico)
            self.dockwidget.btn_calc_sarjeta.clicked.connect(self.calcular_bocas_de_lobo)
            QgsProject.instance().layersAdded.connect(self.atualizar_camadas)
            QgsProject.instance().layersRemoved.connect(self.atualizar_camadas)
            
        self.dockwidget.show()
        self.atualizar_camadas()
        self.atualizar_combo_historico()

    def dock_visibility_changed(self, visible):
        if not visible:
            self.limpar_dados()

    def salvar_no_banco(self):
        # Encontra as camadas "Rede (Temp)" e "PVs (Temp)"
        rede_layer = None
        pv_layer = None
        
        for layer in QgsProject.instance().mapLayers().values():
            if layer.name() == "Rede (Temp)":
                rede_layer = layer
            elif layer.name() == "PVs (Temp)":
                pv_layer = layer
                
        if not rede_layer and not pv_layer:
            self.dockwidget.add_result("Erro: Nenhuma medição temporária encontrada para salvar.")
            return

        # Caminho para o banco local do próprio plugin
        db_path = os.path.join(self.plugin_dir, "medir_3d_db.gpkg")

        try:
            from qgis.core import QgsVectorFileWriter
            import time
            import uuid
            
            # Gerar um ID único se for um novo projeto, senão usar o ativo
            if not self.active_projeto_id:
                projeto_id = str(uuid.uuid4())[:8]
            else:
                projeto_id = self.active_projeto_id
            
            QgsMessageLog.logMessage(f"Salvando projeto: {projeto_id} (Ativo: {self.active_projeto_id})", "Medir 3D", Qgis.Info)
                
            nome_projeto = self.dockwidget.input_nome_projeto.text().strip()
            if not nome_projeto:
                if self.active_projeto_id:
                    # Se estiver atualizando, mantém o nome se o campo estiver vazio
                    nome_projeto = self.dockwidget.combo_historico.currentText().split(' (')[0]
                else:
                    nome_projeto = f"Projeto_{time.strftime('%H%M%S')}"
        
            timestamp_str = time.strftime("%Y-%m-%d %H:%M:%S")

            # Helper function to append or create GeoPackage table
            def save_layer_to_gpkg(layer, table_name, p_id):
                # Se estivermos atualizando, removemos o registro anterior do banco primeiro
                if os.path.exists(db_path):
                    from qgis.core import QgsVectorLayer, QgsFeatureRequest
                    temp_l = QgsVectorLayer(f"{db_path}|layername={table_name}", "del_check", "ogr")
                    if temp_l.isValid():
                        # Encontrar e remover features com o mesmo projeto_id
                        request = QgsFeatureRequest().setFilterExpression(f"\"projeto_id\" = '{p_id}'")
                        feats_to_del = [f.id() for f in temp_l.getFeatures(request)]
                        if feats_to_del:
                            QgsMessageLog.logMessage(f"Removendo {len(feats_to_del)} registros antigos de {table_name} com ID {p_id}", "Medir 3D", Qgis.Info)
                            temp_l.startEditing()
                            for fid in feats_to_del:
                                temp_l.deleteFeature(fid)
                            if not temp_l.commitChanges():
                                QgsMessageLog.logMessage(f"FALHA ao remover registros antigos de {table_name}: {temp_l.lastError().text()}", "Medir 3D", Qgis.Warning)
                        temp_l = None # Força fechamento do provider

                options = QgsVectorFileWriter.SaveVectorOptions()
                options.driverName = "GPKG"
                options.layerName = table_name
                
                if not os.path.exists(db_path):
                    options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile
                else:
                    # Se o arquivo existe e já tem a camada, faremos append
                    temp_l = QgsVectorLayer(f"{db_path}|layername={table_name}", "check", "ogr")
                    if temp_l.isValid():
                        options.actionOnExistingFile = QgsVectorFileWriter.AppendToLayerNoNewFields
                    else:
                        options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer
                    
                res = QgsVectorFileWriter.writeAsVectorFormatV3(layer, db_path, self.iface.mapCanvas().mapSettings().transformContext(), options)
                if res[0] != QgsVectorFileWriter.NoError:
                    QgsMessageLog.logMessage(f"Erro QgsVectorFileWriter ({table_name}): {res[1]}", "Medir 3D", Qgis.Critical)
                    return f"Erro ao salvar {table_name}: {res[1]}"
                return None

            if rede_layer:
                pr_rede = rede_layer.dataProvider()
                campos_atuais = [f.name() for f in rede_layer.fields()]
                novos_campos = []
                if "projeto_id" not in campos_atuais:
                    novos_campos.append(QgsField("projeto_id", QVariant.String))
                if "nome_projeto" not in campos_atuais:
                    novos_campos.append(QgsField("nome_projeto", QVariant.String))
                if "log_completo" not in campos_atuais:
                    novos_campos.append(QgsField("log_completo", QVariant.String))
                if "perfil_path" not in campos_atuais:
                    novos_campos.append(QgsField("perfil_path", QVariant.String))
                if "data_hora" not in campos_atuais:
                    novos_campos.append(QgsField("data_hora", QVariant.String))
                
                if novos_campos:
                    pr_rede.addAttributes(novos_campos)
                    rede_layer.updateFields()
                
                log_text = self.dockwidget.txt_resultados.toPlainText()
                timestamp_file = time.strftime("%Y%m%d_%H%M%S")
                dir_db = os.path.dirname(db_path)
                pasta_perfis = os.path.join(dir_db, "Perfis_Salvos")
                if not os.path.exists(pasta_perfis):
                    os.makedirs(pasta_perfis)
                caminho_img = os.path.join(pasta_perfis, f"perfil_{timestamp_file}.png")
                
                if self.map_tool and self.map_tool.last_pvs:
                    self.map_tool.gerar_perfil(show=False, save_path=caminho_img)
                else:
                    caminho_img = ""

                rede_layer.startEditing()
                for feat in rede_layer.getFeatures():
                    feat.setAttribute("projeto_id", projeto_id)
                    feat.setAttribute("nome_projeto", nome_projeto)
                    feat.setAttribute("log_completo", log_text)
                    feat.setAttribute("perfil_path", caminho_img)
                    feat.setAttribute("data_hora", timestamp_str)
                    rede_layer.updateFeature(feat)
                rede_layer.commitChanges()

                err = save_layer_to_gpkg(rede_layer, "rede_historico", projeto_id)
                if err: self.dockwidget.add_result(err)
            
            if pv_layer:
                pr_pv = pv_layer.dataProvider()
                campos_pv = [f.name() for f in pv_layer.fields()]
                novos_pv = []
                if "projeto_id" not in campos_pv:
                    novos_pv.append(QgsField("projeto_id", QVariant.String))
                if "nome_projeto" not in campos_pv:
                    novos_pv.append(QgsField("nome_projeto", QVariant.String))
                
                if novos_pv:
                    pr_pv.addAttributes(novos_pv)
                    pv_layer.updateFields()
                
                pv_layer.startEditing()
                for feat in pv_layer.getFeatures():
                    feat.setAttribute("projeto_id", projeto_id)
                    feat.setAttribute("nome_projeto", nome_projeto)
                    pv_layer.updateFeature(feat)
                pv_layer.commitChanges()

                err = save_layer_to_gpkg(pv_layer, "pv_historico", projeto_id)
                if err: self.dockwidget.add_result(err)
                
            self.active_projeto_id = projeto_id
            self.dockwidget.add_result(f"SUCESSO! Projeto '{nome_projeto}' salvo em:\n{db_path}")
            self.atualizar_combo_historico()
            self.dockwidget.input_nome_projeto.clear()

        except Exception as e:
            self.dockwidget.add_result(f"Erro Crítico ao Salvar: {str(e)}")

    def limpar_dados(self, permanente=False):
        self.active_projeto_id = None
        # Desativa a ferramenta do mapa se estiver ativa
        if self.map_tool and self.iface.mapCanvas().mapTool() == self.map_tool:
            self.iface.mapCanvas().unsetMapTool(self.map_tool)
            self.map_tool.reset_measurement()
        
        # Limpa o texto da UI
        if self.dockwidget:
            self.dockwidget.txt_resultados.clear()
            
        # Tenta deletar as camadas temporárias e de histórico
        layers_to_remove = []
        for layer in QgsProject.instance().mapLayers().values():
            name = layer.name()
            # Remove camadas temporárias de medição atual
            if name in ["Rede (Temp)", "PVs (Temp)"]:
                layers_to_remove.append(layer.id())
            # Remove camadas carregadas do histórico (REDE_... ou PVs_...)
            elif name.startswith("REDE_") or name.startswith("PVs_"):
                layers_to_remove.append(layer.id())
                
        if layers_to_remove:
            QgsProject.instance().removeMapLayers(layers_to_remove)

    def atualizar_combo_historico(self):
        self.dockwidget.combo_historico.clear()
        db_path = os.path.join(self.plugin_dir, "medir_3d_db.gpkg")
        if not os.path.exists(db_path):
            return

        # Criar uma camada temporária apenas para ler a tabela de histórico
        uri = f"{db_path}|layername=rede_historico"
        layer = QgsVectorLayer(uri, "temp_hist", "ogr")
        if layer.isValid():
            features = list(layer.getFeatures())
            for feat in reversed(features):
                # Usar o nome do projeto se disponível, senão usa a data
                campos = [f.name() for f in feat.fields()]
                nome = feat['nome_projeto'] if 'nome_projeto' in campos and feat['nome_projeto'] else "Sem Nome"
                data = feat['data_hora'] if 'data_hora' in campos else "S/D"
                label = f"{nome} ({data})"
                
                # Guardamos o projeto_id para carregar todas as camadas vinculadas
                p_id = feat['projeto_id'] if 'projeto_id' in campos else str(feat.id())
                self.dockwidget.combo_historico.addItem(label, p_id)

    def excluir_historico(self):
        projeto_id = self.dockwidget.combo_historico.currentData()
        if not projeto_id:
            return

        QgsMessageLog.logMessage(f"Iniciando exclusão do projeto_id: {projeto_id}", "Medir 3D", Qgis.Info)

        projeto_nome = self.dockwidget.combo_historico.currentText()
        
        reply = QMessageBox.question(None, 'Confirmar Exclusão', 
                                    f"Tem certeza que deseja excluir permanentemente o registro:\n'{projeto_nome}'?\n\nIsso removerá os dados do banco, o perfil e as camadas do mapa.",
                                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No)
        
        if reply == QMessageBox.StandardButton.No:
            return

        db_path = os.path.join(self.plugin_dir, "medir_3d_db.gpkg")
        if not os.path.exists(db_path):
            return

        try:
            from qgis.core import QgsVectorLayer, QgsFeatureRequest
            
            # 1. Obter caminho do perfil para deletar o arquivo
            uri_rede = f"{db_path}|layername=rede_historico|subset=\"projeto_id\" = '{projeto_id}'"
            layer_rede = QgsVectorLayer(uri_rede, "check_del", "ogr")
            if layer_rede.isValid() and layer_rede.featureCount() > 0:
                features = list(layer_rede.getFeatures())
                if features:
                    feat = features[0]
                    campos = [f.name() for f in feat.fields()]
                    perfil_path = feat["perfil_path"] if "perfil_path" in campos else None
                    if perfil_path and os.path.exists(perfil_path):
                        try:
                            os.remove(perfil_path)
                            QgsMessageLog.logMessage(f"Perfil removido: {perfil_path}", "Medir 3D", Qgis.Info)
                        except Exception as e:
                            QgsMessageLog.logMessage(f"Falha ao remover arquivo de perfil: {str(e)}", "Medir 3D", Qgis.Warning)

            # 2. Deletar das tabelas do GPKG
            for table in ["rede_historico", "pv_historico"]:
                l = QgsVectorLayer(f"{db_path}|layername={table}", "deleter", "ogr")
                if l.isValid():
                    request = QgsFeatureRequest().setFilterExpression(f"\"projeto_id\" = '{projeto_id}'")
                    fids = [f.id() for f in l.getFeatures(request)]
                    if fids:
                        QgsMessageLog.logMessage(f"Deletando {len(fids)} features da tabela {table} (ID: {projeto_id})", "Medir 3D", Qgis.Info)
                        l.startEditing()
                        for fid in fids:
                            l.deleteFeature(fid)
                        if not l.commitChanges():
                            QgsMessageLog.logMessage(f"Erro ao comitar exclusão em {table}: {l.lastError().text()}", "Medir 3D", Qgis.Warning)
                    l = None

            # 3. Se era o projeto ativo ou se as camadas estão no mapa, resetar UI/Mapa
            self.limpar_dados()
            
            self.iface.mapCanvas().refresh()
            self.dockwidget.add_result(f"Registro {projeto_id} excluído com sucesso e tela atualizada.")
            self.atualizar_combo_historico()

        except Exception as e:
            self.dockwidget.add_result(f"Erro ao excluir: {str(e)}")


    def carregar_historico(self):
        projeto_id = self.dockwidget.combo_historico.currentData()
        if not projeto_id:
            return

        # Limpar antes de carregar
        self.limpar_dados()
        self.active_projeto_id = projeto_id

        db_path = os.path.join(self.plugin_dir, "medir_3d_db.gpkg")
        
        # 1. Carregar Rede
        uri_rede = f"{db_path}|layername=rede_historico|subset=\"projeto_id\" = '{projeto_id}'"
        layer_rede_db = QgsVectorLayer(uri_rede, "load_rede", "ogr")
        
        if not layer_rede_db.isValid() or layer_rede_db.featureCount() == 0:
            self.dockwidget.add_result("Erro ao localizar rede no histórico.")
            return

        features = list(layer_rede_db.getFeatures())
        if not features:
            self.dockwidget.add_result("Erro: Dados geométricos não encontrados no histórico.")
            return
        feat_rede = features[0]
        
        # Restaurar UI
        self.dockwidget.txt_resultados.clear()
        log_text = feat_rede["log_completo"]
        if log_text:
            self.dockwidget.add_result(f"=== PROJETO CARREGADO: {feat_rede['nome_projeto']} ===")
            self.dockwidget.add_result(log_text)
        
        perfil_path = feat_rede["perfil_path"]
        if perfil_path and os.path.exists(perfil_path):
            self.dockwidget.add_result(f"\nAbrindo perfil: {perfil_path}")
            os.startfile(perfil_path)
            
        # 2. Restaurar Estado para o MapTool (Permite Recalcular PVs)
        from qgis.core import QgsPointXY
        if not self.map_tool:
            self.map_tool = MapTool3D(self.iface.mapCanvas(), self.get_camada_selecionada, self.get_inclinacao_rede, self.get_dist_pv, self.get_diameter)
            self.map_tool.measurement_done.connect(self.dockwidget.add_result)
        
        # Extrair pontos da geometria carregada
        geom = feat_rede.geometry()
        # No QGIS 3, asPolyline() funciona para LineString
        self.map_tool.last_points = [QgsPointXY(pt) for pt in geom.asPolyline()]
        self.map_tool.last_pvs = []  # Resetar PVs calculados anteriormente
        self.map_tool.total_dist_2d = feat_rede["dist_2d_m"]
        self.map_tool.total_dist_3d = feat_rede["dist_3d_m"]
            
        # 3. Carregar PVs
        uri_pv = f"{db_path}|layername=pv_historico|subset=\"projeto_id\" = '{projeto_id}'"
        layer_pv_db = QgsVectorLayer(uri_pv, "load_pv", "ogr")
        
        # 4. Adicionar como camadas de memória ATIVAS (Temp) para o usuário
        crs = self.iface.mapCanvas().mapSettings().destinationCrs().authid()
        
        # Rede no mapa (Como Temp para permitir salvar/recalcular)
        view_rede = QgsVectorLayer(f"LineString?crs={crs}", "Rede (Temp)", "memory")
        view_rede.dataProvider().addAttributes(layer_rede_db.fields())
        view_rede.updateFields()
        view_rede.dataProvider().addFeatures([feat_rede])
        QgsProject.instance().addMapLayer(view_rede)
        
        # PVs no mapa (Como Temp)
        if layer_pv_db.isValid() and layer_pv_db.featureCount() > 0:
            view_pv = QgsVectorLayer(f"Point?crs={crs}", "PVs (Temp)", "memory")
            view_pv.dataProvider().addAttributes(layer_pv_db.fields())
            view_pv.updateFields()
            view_pv.dataProvider().addFeatures(list(layer_pv_db.getFeatures()))
            QgsProject.instance().addMapLayer(view_pv)
            self.dockwidget.add_result(f"\nRecuperados {layer_pv_db.featureCount()} PVs.")
            
        self.dockwidget.add_result("\nPronto para novo cálculo ou edição.")

    def atualizar_camadas(self, layers=None):
        settings = QgsSettings()
        # Salva o nome da camada atualmente selecionada (se houver) antes de limpar
        camada_atual = self.dockwidget.combo_layer.currentText()
        if not camada_atual: camada_atual = settings.value("Medir3D/lastLayer", "")
        
        bacia_atual = self.dockwidget.combo_bacias.currentText()
        if not bacia_atual: bacia_atual = settings.value("Medir3D/lastBacia", "")
        
        vias_atual = self.dockwidget.combo_vias.currentText()
        if not vias_atual: vias_atual = settings.value("Medir3D/lastVias", "")

        self.dockwidget.combo_layer.blockSignals(True)
        self.dockwidget.combo_bacias.blockSignals(True)
        self.dockwidget.combo_vias.blockSignals(True)
        
        self.dockwidget.combo_layer.clear()
        self.dockwidget.combo_bacias.clear()
        self.dockwidget.combo_vias.clear()
        
        todas_camadas = QgsProject.instance().mapLayers().values()
        for layer in todas_camadas:
            if layer.type() == QgsMapLayerType.RasterLayer:
                self.dockwidget.combo_layer.addItem(layer.name(), layer.id())
            elif layer.type() == QgsMapLayerType.VectorLayer:
                geom_type = layer.geometryType()
                from qgis.core import QgsWkbTypes
                if geom_type == QgsWkbTypes.PolygonGeometry:
                    self.dockwidget.combo_bacias.addItem(layer.name(), layer.id())
                elif geom_type == QgsWkbTypes.LineGeometry:
                    self.dockwidget.combo_vias.addItem(layer.name(), layer.id())
        
        # Tenta restaurar a seleção anterior pelo nome
        index_raster = self.dockwidget.combo_layer.findText(camada_atual)
        if index_raster >= 0: self.dockwidget.combo_layer.setCurrentIndex(index_raster)
            
        index_bacia = self.dockwidget.combo_bacias.findText(bacia_atual)
        if index_bacia >= 0: self.dockwidget.combo_bacias.setCurrentIndex(index_bacia)
            
        index_vias = self.dockwidget.combo_vias.findText(vias_atual)
        if index_vias >= 0: self.dockwidget.combo_vias.setCurrentIndex(index_vias)
            
        self.dockwidget.combo_layer.blockSignals(False)
        self.dockwidget.combo_bacias.blockSignals(False)
        self.dockwidget.combo_vias.blockSignals(False)
        
        self.atualizar_campos_vias()

    def guardar_selecao_camada(self):
        if self.dockwidget:
            layer_name = self.dockwidget.combo_layer.currentText()
            if layer_name:
                settings = QgsSettings()
                settings.setValue("Medir3D/lastLayer", layer_name)
            
            bacia_name = self.dockwidget.combo_bacias.currentText()
            if bacia_name:
                settings = QgsSettings()
                settings.setValue("Medir3D/lastBacia", bacia_name)

    def atualizar_campos_vias(self):
        if not self.dockwidget: return
        
        vias_name = self.dockwidget.combo_vias.currentText()
        if vias_name:
            settings = QgsSettings()
            settings.setValue("Medir3D/lastVias", vias_name)
            
        layer_id = self.dockwidget.combo_vias.currentData()
        self.dockwidget.combo_campo_n.clear()
        self.dockwidget.combo_campo_lamina.clear()
        self.dockwidget.combo_campo_caimento.clear()
        
        if layer_id:
            layer = QgsProject.instance().mapLayer(layer_id)
            if layer:
                fields = [f.name() for f in layer.fields()]
                self.dockwidget.combo_campo_n.addItems(fields)
                self.dockwidget.combo_campo_lamina.addItems(fields)
                self.dockwidget.combo_campo_caimento.addItems(fields)

    def get_camada_selecionada(self):
        layer_id = self.dockwidget.combo_layer.currentData()
        if layer_id:
            return QgsProject.instance().mapLayer(layer_id)
        return None
        
    def get_inclinacao_rede(self):
        try:
            val = float(self.dockwidget.input_inclinacao.text().replace(',', '.'))
            if val > 4.5:
                self.dockwidget.add_result(f"ALERTA: Declividade {val:.1f}% excede limite. Ajustado para 4,5%.")
                self.dockwidget.input_inclinacao.setText("4.5")
                return 4.5
            return val
        except:
            return 1.0 # Default 1%
            
    def get_dist_pv(self):
        try:
            return float(self.dockwidget.input_dist_pv.text().replace(',', '.'))
        except:
            return 40.0

    def atualizar_pvs(self):
        raster_layer = self.get_camada_selecionada()
        if not raster_layer:
            self.dockwidget.add_result("Erro: Nenhuma camada raster selecionada.")
            return
        if not self.map_tool:
            # Recriar map_tool se foi destruído
            self.map_tool = MapTool3D(self.iface.mapCanvas(), self.get_camada_selecionada, self.get_inclinacao_rede, self.get_dist_pv, self.get_diameter)
            self.map_tool.measurement_done.connect(self.dockwidget.add_result)
            self.dockwidget.add_result("Erro: Nenhuma medição anterior. Trace um caminho primeiro.")
            return
        if not self.map_tool.last_points:
            self.dockwidget.add_result("Erro: Nenhuma medição anterior. Trace um caminho primeiro.")
            return
        slope = self.get_inclinacao_rede()
        self.dockwidget.add_result(f"Recalculando PVs com declive {slope:.1f}%...")
        self.map_tool.refazer_pvs(raster_layer)

    def ver_perfil(self):
        if self.map_tool:
            self.map_tool.gerar_perfil()
        else:
            self.dockwidget.add_result("Erro: Nenhum perfil disponível. Faça uma medição primeiro.")

    def get_diameter(self):
        try:
            val = float(self.dockwidget.input_diametro.text().replace(',', '.'))
            return val
        except:
            return 200.0

    def ativar_medicao(self):
        self.active_projeto_id = None
        if not self.map_tool:
            self.map_tool = MapTool3D(self.iface.mapCanvas(), self.get_camada_selecionada, self.get_inclinacao_rede, self.get_dist_pv, self.get_diameter)
            self.map_tool.measurement_done.connect(self.dockwidget.add_result)
        
        self.iface.mapCanvas().setMapTool(self.map_tool)
        self.dockwidget.add_result("Ferramenta 3D ativada.\n- ESQUERDO: Adicionar pontos do traçado\n- DIREITO: Finalizar e Gerar PVs")

    def calcular_capacidade_sarjeta(self, n, y_max, sx, i_long):
        if i_long <= 0 or sx <= 0:
            return 0.0
        z = 1.0 / sx
        area = (z * (y_max ** 2)) / 2.0
        perimetro_molhado = y_max + (y_max * ((1 + z**2) ** 0.5))
        raio_hidraulico = area / perimetro_molhado
        q_cap = (1.0 / n) * area * (raio_hidraulico ** (2/3)) * (i_long ** 0.5)
        return q_cap

    def calcular_bocas_de_lobo(self):
        self.dockwidget.add_result("Iniciando cálculo de sarjetas...")
        raster_layer = self.get_camada_selecionada()
        if not raster_layer:
            self.dockwidget.add_result("Erro: Selecione uma camada raster (MDT/MDS).")
            return
            
        vias_id = self.dockwidget.combo_vias.currentData()
        bacias_id = self.dockwidget.combo_bacias.currentData()
        
        if not vias_id or not bacias_id:
            self.dockwidget.add_result("Erro: Selecione as camadas de Vias e Bacias.")
            return
            
        layer_vias = QgsProject.instance().mapLayer(vias_id)
        layer_bacias = QgsProject.instance().mapLayer(bacias_id)
        
        if not layer_vias or not layer_bacias:
            self.dockwidget.add_result("Erro: Camadas não encontradas.")
            return

        is_dynamic = self.dockwidget.chk_dinamico.isChecked()
        
        try:
            n_fixo = float(self.dockwidget.input_manning.text().replace(',', '.'))
            lam_fixo = float(self.dockwidget.input_lamina.text().replace(',', '.'))
            cai_fixo = float(self.dockwidget.input_caimento.text().replace(',', '.')) / 100.0
            q_engol_fixo = float(self.dockwidget.input_engolimento.text().replace(',', '.'))
            margem_segur = float(self.dockwidget.input_margem.text().replace(',', '.')) / 100.0
            dist_max = float(self.dockwidget.input_dist_max.text().replace(',', '.'))
            dist_min = float(self.dockwidget.input_dist_min.text().replace(',', '.'))
        except ValueError:
            self.dockwidget.add_result("Erro: Parâmetros numéricos inválidos.")
            return

        campo_n = self.dockwidget.combo_campo_n.currentText()
        campo_lam = self.dockwidget.combo_campo_lamina.currentText()
        campo_cai = self.dockwidget.combo_campo_caimento.currentText()

        crs = self.iface.mapCanvas().mapSettings().destinationCrs().authid()
        from qgis.core import QgsVectorLayer, QgsField, QgsFeature, QgsGeometry, QgsPointXY, QgsRaster, QgsSpatialIndex, QgsCoordinateTransform, QgsWkbTypes
        from qgis.PyQt.QtCore import QVariant
        import math
        
        layer_bl = QgsVectorLayer(f"Point?crs={crs}", "Bocas de Lobo (Temp)", "memory")
        pr_bl = layer_bl.dataProvider()
        
        pr_bl.addAttributes([
            QgsField("q_cap", QVariant.Double),
            QgsField("q_acc", QVariant.Double),
            QgsField("i_long", QVariant.Double),
            QgsField("qtd_grelhas", QVariant.Int)
        ])
        layer_bl.updateFields()
        
        features_bl = []
        
        def get_z(pt):
            canvas_crs = self.iface.mapCanvas().mapSettings().destinationCrs()
            raster_crs = raster_layer.crs()
            if canvas_crs != raster_crs:
                transform = QgsCoordinateTransform(canvas_crs, raster_crs, QgsProject.instance())
                pt_trans = transform.transform(pt)
            else:
                pt_trans = pt
            ident = raster_layer.dataProvider().identify(pt_trans, QgsRaster.IdentifyFormatValue)
            if ident.isValid() and ident.results():
                for val in ident.results().values():
                    if val is not None:
                        return float(val)
            return 0.0

        index_vias = QgsSpatialIndex(layer_vias.getFeatures())
        vias_selecionadas_ids = [f.id() for f in layer_vias.selectedFeatures()]
        
        selected_bacias = list(layer_bacias.selectedFeatures())
        if not selected_bacias:
            self.dockwidget.add_result("Erro: Selecione a(s) bacia(s) no mapa.")
            return

        self.dockwidget.add_result(f"\n--- CÁLCULO DINÂMICO (Racional Pro) ---")
        
        for bacia in selected_bacias:
            bacia_geom = bacia.geometry()
            area_ha = bacia_geom.area() / 10000.0
            q_total_bacia = (0.5 * 150 * area_ha) / 360.0
            
            self.dockwidget.add_result(f"\nBacia {bacia.id()}: Área={area_ha:.2f}ha, Q_total={q_total_bacia:.4f}m3/s")
            
            # Passo 1: Identificar e preparar vias na bacia
            vias_na_bacia = []
            l_total_vias = 0.0
            candidate_ids = index_vias.intersects(bacia_geom.boundingBox())
            for v_id in candidate_ids:
                if vias_selecionadas_ids and v_id not in vias_selecionadas_ids: continue
                fv = layer_vias.getFeature(v_id)
                if fv.geometry().intersects(bacia_geom):
                    inter = fv.geometry().intersection(bacia_geom)
                    for part in inter.asGeometryCollection() if inter.isMultipart() else [inter]:
                        lin = part.asPolyline()
                        if len(lin) < 2: continue
                        z_i, z_f = get_z(QgsPointXY(lin[0])), get_z(QgsPointXY(lin[-1]))
                        # Garante orientação montante -> jusante
                        if z_f > z_i: lin.reverse(); z_i, z_f = z_f, z_i
                        dist = part.length()
                        if dist < 1.0: continue
                        vias_na_bacia.append({'geom': part, 'pts': lin, 'zi': z_i, 'zf': z_f, 'L': dist, 'feat': fv})
                        l_total_vias += dist

            if l_total_vias == 0: continue
            q_linear = q_total_bacia / l_total_vias # m3/s por metro linear
            
            # Passo 2: Ordenação Topológica Simplificada (por Z máximo)
            vias_na_bacia.sort(key=lambda x: x['zi'], reverse=True)
            
            # Dicionário para rastrear vazão que chega ao final de cada via
            flow_at_point = {} # (x,y) -> q_acumulado

            for vdata in vias_na_bacia:
                p_ini = (round(vdata['pts'][0].x(), 2), round(vdata['pts'][0].y(), 2))
                q_acc = flow_at_point.get(p_ini, 0.0)
                
                # Parâmetros hidráulicos
                n, lam, cai = n_fixo, lam_fixo, cai_fixo
                if is_dynamic:
                    fv = vdata['feat']
                    if fv[campo_n] is not None: n = float(fv[campo_n])
                    if fv[campo_lam] is not None: lam = float(fv[campo_lam])
                    if fv[campo_cai] is not None: cai = float(fv[campo_cai]) / 100.0
                
                i_long = max(0.001, abs(vdata['zi'] - vdata['zf']) / vdata['L'])
                q_cap = self.calcular_capacidade_sarjeta(n, lam, cai, i_long)
                
                # 4. Correção de Eficiência por Declividade (Splash-over)
                if i_long > 0.08:
                    fator_e = 0.50
                elif i_long > 0.04:
                    fator_e = 0.75
                else:
                    fator_e = 1.0
                
                q_engol_real = q_engol_fixo * fator_e
                
                # Percorre a via em passos de 10m
                passo = 10.0
                dist_percorrida = 0.0
                dist_desde_ultima_bl = 0.0
                pts = vdata['pts']
                
                last_fbl_index_in_this_via = -1
                
                while dist_percorrida < vdata['L']:
                    segmento_l = min(passo, vdata['L'] - dist_percorrida)
                    q_acc += q_linear * segmento_l
                    dist_percorrida += segmento_l
                    dist_desde_ultima_bl += segmento_l
                    
                    is_final_segment = dist_percorrida >= vdata['L'] - 3.0
                    
                    gatilho_hidraulico = q_acc > (q_cap * margem_segur)
                    gatilho_geometrico = dist_desde_ultima_bl >= dist_max
                    # 3. Gatilho Topológico: esquina/ponto baixo com água considerável
                    gatilho_topologico = is_final_segment and q_acc > (q_engol_real * 0.5)
                    
                    if gatilho_hidraulico or gatilho_geometrico or gatilho_topologico:
                        # 2. Agrupamento em Baterias
                        vazao_a_abater = q_acc - (q_cap * margem_segur) if gatilho_hidraulico else q_acc
                        
                        if vazao_a_abater <= 0 and (gatilho_geometrico or gatilho_topologico):
                             qtd_novas = 1 # Para manter o espaçamento/secar esquina
                        else:
                             qtd_novas = math.ceil(vazao_a_abater / q_engol_real)
                        
                        # 1. Trava de Distância Mínima
                        if dist_desde_ultima_bl < dist_min and last_fbl_index_in_this_via != -1:
                            # Acumula na última bateria dessa mesma via
                            last_fbl = features_bl[last_fbl_index_in_this_via]
                            attr = last_fbl.attributes()
                            attr[3] += qtd_novas
                            last_fbl.setAttributes(attr)
                            
                            q_acc = max(0.0, q_acc - (qtd_novas * q_engol_real))
                        else:
                            # Lança nova Boca de Lobo (agora sem limite físico estrito, refletindo a necessidade real)
                            bl_pos = vdata['geom'].interpolate(dist_percorrida).asPoint()
                            fbl = QgsFeature()
                            fbl.setGeometry(QgsGeometry.fromPointXY(bl_pos))
                            fbl.setAttributes([round(q_cap, 4), round(q_acc, 4), round(i_long, 4), qtd_novas])
                            features_bl.append(fbl)
                            last_fbl_index_in_this_via = len(features_bl) - 1
                            
                            q_acc = max(0.0, q_acc - (qtd_novas * q_engol_real))
                            dist_desde_ultima_bl = 0.0 # Reseta a distância
                
                # Transmite vazão residual para o ponto final
                p_fim = (round(vdata['pts'][-1].x(), 2), round(vdata['pts'][-1].y(), 2))
                flow_at_point[p_fim] = flow_at_point.get(p_fim, 0.0) + q_acc

        if features_bl:
            pr_bl.addFeatures(features_bl)
            QgsProject.instance().addMapLayer(layer_bl)
            self.dockwidget.add_result(f"Sucesso: {len(features_bl)} BLs lançadas com fluxo dinâmico.")
        else:
            self.dockwidget.add_result("Nenhuma BL necessária.")

